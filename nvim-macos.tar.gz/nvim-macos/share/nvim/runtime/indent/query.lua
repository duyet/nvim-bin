-- Neovim indent file
-- Language:	Tree-sitter query
-- Last Change:	2022 Mar 29

-- it's a lisp!
vim.cmd([[ runtime! indent/lisp.vim ]])
